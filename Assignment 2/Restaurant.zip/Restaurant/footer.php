  <footer>
                <p>&copy; <?php echo date("Y"); ?> CST8238. All Rights Reserved.</p> 
            </footer>
        </div><!-- End Wrapper -->
    </body>
</html>